package com.cybersoft.java10.object;

public class TruongHoc {
	private String tenTrg;
	private ListSinhVien listSV;
}
