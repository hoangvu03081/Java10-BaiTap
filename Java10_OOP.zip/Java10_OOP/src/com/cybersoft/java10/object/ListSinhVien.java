package com.cybersoft.java10.object;
import java.util.*;
public class ListSinhVien {
	private ArrayList<SinhVien> listSV;
	public ListSinhVien(){
		listSV=new ArrayList<SinhVien>();
	}
	public void nhapListSV() {
		Scanner scanner=new Scanner(System.in);
		int choice=-1;
		while(choice!=0) {
			SinhVien temp=new SinhVien();
			temp.nhapSV();
			listSV.add(temp);
			System.out.println("Nhap 0 de ngung: ");
			choice=scanner.nextInt();
		}
	}
	public void inHocLuc() {
		for(SinhVien x:listSV) {
			float diemTB=x.getDiemTB();
			if(diemTB>=9)
				System.out.println(x.getTen()+" Hoc Luc: Xuat Sac");
			else if(diemTB>=8)
				System.out.println(x.getTen()+" Hoc Luc: Gioi");
			else if(diemTB>=6)
				System.out.println(x.getTen()+" Hoc Luc: Kha");
			else if(diemTB>=5)
				System.out.println(x.getTen()+" Hoc Luc: Trung Binh");
			else
				System.out.println(x.getTen()+" Hoc Luc: Yeu");
		}
	}
	public void inSVCaoDiemNhat() {
		float max=0;
		SinhVien svMax=null;
		for(SinhVien x:listSV) {
			if(x.getDiemTB()>max) {
				svMax=x;
				max=x.getDiemTB();
			}
		}
		if(svMax!=null)
			System.out.println(svMax.getTen()+ " co diem so cao nhat");
	}
	
	public void inSVYeu() {
		System.out.println("List SV Yeu: ");
		for(SinhVien x:listSV) {
			if(x.getDiemTB()<=5) {
				System.out.println(x.getTen());
			}
		}
	}
	
	public SinhVien timSVTheoTen() {
		Scanner scanner=new Scanner(System.in);
		String tenSV=new String();
		System.out.println("Nhap ten SV: ");
		tenSV=scanner.nextLine();
		for(SinhVien x:listSV) {
			if(tenSV==x.getTen())
			{
				System.out.println("Tim thay sv");
				return x;
			}
		}
		return null;
	}
	
	public void xoaSV() {
		SinhVien temp;
		temp=timSVTheoTen();
		if(temp==null)
			return;
		listSV.remove(temp);
		System.out.println("Xoa thanh cong");
	}
	
	
}
