package com.cybersoft.java10.object;
import java.util.*;
public class SinhVien {
private String 	hoTen;
private String 	maSV;
private float 	diemToan;
private float	diemLy;
private	float	diemHoa;
private float	diemTB;
public void nhapSV() {
	Scanner scanner=new Scanner(System.in);
	String temp;
	System.out.println("Nhap ten sv:");
	temp=scanner.nextLine();
	hoTen=temp;
	System.out.println("Nhap ma sv");
	temp=scanner.nextLine();
	maSV=temp;
}

public void nhapDiem() {
	Scanner scanner=new Scanner(System.in);
	float temp;
	System.out.print("Nhap diem toan: ");
	temp=scanner.nextFloat();
	if(temp<0||temp>10) {
		System.out.println("Format diem khong hop le");
		return;
	}
	diemToan=temp;
	System.out.print("Nhap diem ly: ");
	temp=scanner.nextFloat();
	if(temp<0||temp>10) {
		System.out.println("Format diem khong hop le");
		return;
	}
	diemLy=temp;
	System.out.print("Nhap diem hoa: ");
	temp=scanner.nextFloat();
	if(temp<0||temp>10) {
		System.out.println("Format diem khong hop le");
		return;
	}
	diemHoa=temp;
	diemTB=(diemToan+diemLy+diemHoa)/3;
}

public float getDiemTB() {
	return diemTB;
}

public String getTen() {
	return hoTen;
}
}
